package com.utility.calc

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// Compass ka dial (bina internet, sirf phone ke sensor se chalta hai)
class CompassView(ctx: Context) : View(ctx) {

    var azimuth = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val marker = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = Math.min(width, height) / 2f * 0.88f

        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#1C1C1E")
        canvas.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r * 0.02f
        paint.color = Color.parseColor("#48484A")
        canvas.drawCircle(cx, cy, r, paint)

        canvas.save()
        canvas.rotate(-azimuth, cx, cy)

        for (i in 0 until 72) {
            val major = i % 6 == 0
            val len = if (major) r * 0.10f else r * 0.05f
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (major) r * 0.012f else r * 0.006f
            paint.color = if (major) Color.WHITE else Color.GRAY
            canvas.drawLine(cx, cy - r + r * 0.03f, cx, cy - r + r * 0.03f + len, paint)
            canvas.rotate(5f, cx, cy)
        }

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * 0.16f
        val labels = arrayOf("N", "E", "S", "W")
        for (k in 0 until 4) {
            paint.color = if (k == 0) Color.parseColor("#FF453A") else Color.WHITE
            canvas.drawText(labels[k], cx, cy - r * 0.68f + paint.textSize / 3f, paint)
            canvas.rotate(90f, cx, cy)
        }
        canvas.restore()

        // Upar ka fixed nishan
        marker.reset()
        marker.moveTo(cx - r * 0.05f, cy - r * 1.09f)
        marker.lineTo(cx + r * 0.05f, cy - r * 1.09f)
        marker.lineTo(cx, cy - r * 0.98f)
        marker.close()
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#FF9F0A")
        canvas.drawPath(marker, paint)

        // Beech ka dot
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * 0.03f, paint)
    }
}

// Asli chalne wala Compass. Secret settings kholne ke liye compass dial ko LAMBA DABAO.
class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var compass: CompassView
    private lateinit var heading: TextView
    private lateinit var sm: SensorManager
    private val gravity = FloatArray(3)
    private val geo = FloatArray(3)
    private var hasG = false
    private var hasM = false
    private var cur = 0f
    private val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val p = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#000000"))
            setPadding(p, p * 2, p, p)
        }
        heading = TextView(this).apply {
            text = "--"
            textSize = 40f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(
            heading,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        compass = CompassView(this)
        compass.setOnLongClickListener {
            startActivity(Intent(this, AdminActivity::class.java))
            true
        }
        root.addView(compass, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val hint = TextView(this).apply {
            text = "Calibrate: move your phone in a figure 8"
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        root.addView(
            hint,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        setContentView(root)

        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    override fun onResume() {
        super.onResume()
        val rot = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rot != null) {
            sm.registerListener(this, rot, SensorManager.SENSOR_DELAY_GAME)
        } else {
            val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
            if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
            if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent?) {
        if (e == null) return
        val rm = FloatArray(9)
        val ok: Boolean
        when (e.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rm, e.values)
                ok = true
            }
            Sensor.TYPE_ACCELEROMETER -> {
                System.arraycopy(e.values, 0, gravity, 0, 3)
                hasG = true
                ok = hasG && hasM && SensorManager.getRotationMatrix(rm, null, gravity, geo)
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                System.arraycopy(e.values, 0, geo, 0, 3)
                hasM = true
                ok = hasG && hasM && SensorManager.getRotationMatrix(rm, null, gravity, geo)
            }
            else -> ok = false
        }
        if (!ok) return

        val o = FloatArray(3)
        SensorManager.getOrientation(rm, o)
        val az = ((Math.toDegrees(o[0].toDouble()) + 360.0) % 360.0).toFloat()

        var diff = az - cur
        while (diff > 180f) diff -= 360f
        while (diff < -180f) diff += 360f
        cur = (cur + diff * 0.15f + 360f) % 360f

        compass.azimuth = cur
        compass.invalidate()
        val idx = ((cur + 22.5f) / 45f).toInt() % 8
        heading.text = "${cur.toInt()}° ${names[idx]}"
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
