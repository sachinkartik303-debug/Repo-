package com.utility.calc

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// Secret settings: password set karna, apps chunna, service ON karna
class AdminActivity : AppCompatActivity() {

    private var authed = false

    override fun onStart() {
        super.onStart()
        render()
    }

    override fun onStop() {
        super.onStop()
        authed = false   // bahar jaate hi dobara password maangega
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(20), dp(20), dp(20))
    }

    private fun passwordField(h: String) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun render() {
        when {
            !Prefs.hasPassword(this) -> setupScreen()
            !authed -> loginScreen()
            else -> listScreen()
        }
    }

    private fun setupScreen() {
        val col = column()
        col.addView(TextView(this).apply { text = "Apna password set karo"; textSize = 22f })
        val p1 = passwordField("Password (kam se kam 4 characters)")
        val p2 = passwordField("Dobara likho")
        col.addView(p1)
        col.addView(p2)
        col.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                val a = p1.text.toString()
                when {
                    a.length < 4 -> p1.error = "Bahut chhota hai"
                    a != p2.text.toString() -> p2.error = "Match nahi kiya"
                    else -> {
                        Prefs.setPassword(this@AdminActivity, a)
                        authed = true
                        render()
                    }
                }
            }
        })
        setContentView(col)
    }

    private fun loginScreen() {
        val col = column()
        col.addView(TextView(this).apply { text = "Password"; textSize = 22f })
        val p = passwordField("Password")
        col.addView(p)
        col.addView(Button(this).apply {
            text = "Open"
            setOnClickListener {
                if (Prefs.check(this@AdminActivity, p.text.toString())) {
                    authed = true
                    render()
                } else {
                    p.error = "Galat password"
                }
            }
        })
        setContentView(col)
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s?.contains("$packageName/") == true
    }

    private fun listScreen() {
        val col = column()
        col.addView(TextView(this).apply {
            text = if (serviceEnabled()) "Lock: ON" else "Lock: OFF. Neeche wale button se ON karo."
            textSize = 18f
        })
        col.addView(Button(this).apply {
            text = "Accessibility settings kholo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "App settings (battery: Unrestricted karo)"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        })
        col.addView(TextView(this).apply {
            text = "Jo apps lock karne hain unhe tick karo:"
            textSize = 16f
            setPadding(0, dp(12), 0, dp(4))
        })

        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }

        val locked = Prefs.lockedApps(this)
        for ((pkg, name) in apps) {
            col.addView(CheckBox(this).apply {
                text = name
                isChecked = pkg in locked
                setOnCheckedChangeListener { _, on -> Prefs.setLocked(this@AdminActivity, pkg, on) }
            })
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
