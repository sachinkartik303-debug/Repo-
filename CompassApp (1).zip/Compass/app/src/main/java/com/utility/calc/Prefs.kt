package com.utility.calc

import android.content.Context
import java.security.SecureRandom
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Prefs {
    // Jo apps abhi unlock hain (sirf memory me)
    val unlocked: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()

    // Lock screen abhi kis app ke liye dikh rahi hai
    @Volatile var showing: String = ""

    private fun sp(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(pw: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 20_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.getEncoder().encodeToString(bytes)
    }

    fun hasPassword(c: Context) = sp(c).contains("hash")

    fun setPassword(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp(c).edit()
            .putString("salt", Base64.getEncoder().encodeToString(salt))
            .putString("hash", hash(pw, salt))
            .apply()
    }

    fun check(c: Context, pw: String): Boolean {
        if (pw.isEmpty()) return false
        return try {
            val s = sp(c)
            val saltStr = s.getString("salt", null) ?: return false
            val salt = Base64.getDecoder().decode(saltStr)
            hash(pw, salt) == s.getString("hash", null)
        } catch (e: Exception) {
            false
        }
    }

    fun lockedApps(c: Context): Set<String> = sp(c).getStringSet("apps", emptySet()) ?: emptySet()

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val set = lockedApps(c).toMutableSet()
        if (on) set.add(pkg) else set.remove(pkg)
        sp(c).edit().putStringSet("apps", set).apply()
    }
}
