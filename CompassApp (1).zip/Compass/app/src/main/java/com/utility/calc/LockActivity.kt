package com.utility.calc

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

// Ye screen "app not responding" jaisi dikhti hai.
// Asli password box dekhne ke liye upar wale text ko LAMBA DABAO (long press).
class LockActivity : AppCompatActivity() {

    private var target = ""
    private lateinit var titleView: TextView
    private lateinit var secret: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2B2D31"))
                cornerRadius = dp(28).toFloat()
            }
        }

        titleView = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(16))
            setOnLongClickListener { reveal(); true }
        }
        card.addView(titleView)

        secret = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        input = EditText(this).apply {
            hint = "Password"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        secret.addView(input)
        secret.addView(Button(this).apply {
            text = "Unlock"
            setOnClickListener { tryUnlock() }
        })
        val canBio = BiometricManager.from(this)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        if (canBio) {
            secret.addView(Button(this).apply {
                text = "Fingerprint"
                setOnClickListener { fingerprint() }
            })
        }
        card.addView(secret)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        row.addView(link("Close app"))
        row.addView(link("Wait"))
        card.addView(row)

        val root = FrameLayout(this)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        )
        lp.setMargins(dp(32), 0, dp(32), 0)
        root.addView(card, lp)
        setContentView(root)

        setTarget(intent.getStringExtra("pkg") ?: "")
    }

    private fun link(label: String): TextView {
        val p = (14 * resources.displayMetrics.density).toInt()
        return TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.parseColor("#8AB4F8"))
            setPadding(p, p, p, p)
            setOnClickListener { goHome() }
        }
    }

    private fun setTarget(pkg: String) {
        target = pkg
        Prefs.showing = pkg
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        titleView.text = "$label isn't responding"
        secret.visibility = View.GONE
        input.text.clear()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        setTarget(intent.getStringExtra("pkg") ?: "")
    }

    override fun onResume() {
        super.onResume()
        Prefs.showing = target
    }

    override fun onStop() {
        super.onStop()
        Prefs.showing = ""
    }

    private fun reveal() {
        secret.visibility = View.VISIBLE
        input.requestFocus()
        getSystemService(InputMethodManager::class.java)
            .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun tryUnlock() {
        if (Prefs.check(this, input.text.toString())) {
            unlock()
        } else {
            input.error = "Wrong password"
            input.text.clear()
        }
    }

    private fun fingerprint() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = unlock()
            })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock")
                .setNegativeButtonText("Cancel")
                .build()
        )
    }

    private fun unlock() {
        if (target.isEmpty()) {
            goHome()
            return
        }
        Prefs.unlocked.add(target)
        Prefs.showing = ""
        finish()
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    // Back dabane par home par bhej do, locked app nahi khulega
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}
