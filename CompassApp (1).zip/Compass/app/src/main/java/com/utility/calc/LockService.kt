package com.utility.calc

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat

class LockService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var keyboards: Set<String> = emptySet()
    private var homes: Set<String> = emptySet()
    private var current = ""
    private var lastPkg = ""
    private var lastLaunch = 0L
    private val pending = HashMap<String, Runnable>()

    // Ye system packages (dialog, settings panel, permission popup) app chhodna nahi maane jaate
    private val neutral = setOf(
        "com.android.systemui", "android", "com.android.settings",
        "com.android.permissioncontroller", "com.google.android.permissioncontroller"
    )

    // Screen off hote hi sab dobara lock
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            Prefs.unlocked.clear()
            cancelAll()
            current = ""
        }
    }

    // Har 0.7 second me check: koi event chhoot jaye to bhi lock lag jayega
    private val tick = object : Runnable {
        override fun run() {
            try {
                val pm = getSystemService(PowerManager::class.java)
                if (pm.isInteractive) {
                    foregroundPkg()?.let { consider(it) }
                }
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 700)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            val imm = getSystemService(InputMethodManager::class.java)
            keyboards = imm.enabledInputMethodList.map { it.packageName }.toSet()
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homes = packageManager.queryIntentActivities(homeIntent, 0)
                .map { it.activityInfo.packageName }
                .filter { it != "com.android.settings" }
                .toSet()
        } catch (e: Exception) {
        }
        try {
            ContextCompat.registerReceiver(
                this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(screenOff)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        try {
            val pkg = e.packageName?.toString() ?: return
            if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                if (pkg == "com.android.systemui") {
                    val cls = e.className?.toString() ?: ""
                    if (cls.contains("recent", ignoreCase = true)) {
                        Prefs.unlocked.clear()
                        cancelAll()
                        current = ""
                    }
                    return
                }
                if (pkg in Prefs.lockedApps(this)) {
                    consider(pkg)       // locked app: turant lock
                    return
                }
            }
            foregroundPkg()?.let { consider(it) }
        } catch (ex: Exception) {
        }
    }

    // Abhi screen par kaun sa app sabse upar hai
    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        val list = windows ?: return null
        for (w in list) {
            if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION && w.isActive) {
                val root = w.root ?: return null
                val p = root.packageName?.toString()
                root.recycle()
                return p
            }
        }
        return null
    }

    private fun consider(pkg: String) {
        if (pkg == packageName || pkg in keyboards) return
        if (pkg in neutral && pkg !in Prefs.lockedApps(this)) return
        onForeground(pkg)
    }

    private fun onForeground(pkg: String) {
        if (pkg != current) {
            val prev = current
            current = pkg
            if (pkg in homes) {
                // Home / launcher aaya = app band hua, sab dobara lock
                Prefs.unlocked.clear()
                cancelAll()
            } else if (prev.isNotEmpty() && prev in Prefs.unlocked) {
                // Dusre app par gaye: 8 second ke baad hi relock (turant wapas aao to nahi)
                scheduleRelock(prev)
            }
            cancel(pkg)
        }
        if (pkg in Prefs.lockedApps(this) && pkg !in Prefs.unlocked) {
            showLock(pkg)
        }
    }

    private fun scheduleRelock(p: String) {
        cancel(p)
        val r = Runnable {
            Prefs.unlocked.remove(p)
            pending.remove(p)
        }
        pending[p] = r
        handler.postDelayed(r, 8000)
    }

    private fun cancel(p: String) {
        pending.remove(p)?.let { handler.removeCallbacks(it) }
    }

    private fun cancelAll() {
        for (r in pending.values) handler.removeCallbacks(r)
        pending.clear()
    }

    private fun showLock(pkg: String) {
        if (Prefs.showing == pkg) return
        val now = SystemClock.elapsedRealtime()
        if (pkg == lastPkg && now - lastLaunch < 600) return
        lastPkg = pkg
        lastLaunch = now
        try {
            startActivity(
                Intent(this, LockActivity::class.java)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                    .putExtra("pkg", pkg)
            )
        } catch (e: Exception) {
        }
    }

    override fun onInterrupt() {}
}
